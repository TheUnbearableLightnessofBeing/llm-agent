from langchain.tools import BaseTool, StructuredTool, Tool, tool
from langchain.pydantic_v1 import BaseModel, Field
from langchain_core.tools import ToolException
from agent.tools.tool_config import *
import json

import jieba
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

import numpy as np
import requests




def get_tools():
    tools = [tavily,yiwan]
    tool_names = ",".join([t.name for t in tools])
    tool_descs = []  # 拼接工具详情
    for t in tools:
        args_desc = []
        for name, info in t.args.items():
            args_desc.append(
                {'name': name, 'description': info['description'] if 'description' in info else '',
                 'type': info['type']})
        args_desc = json.dumps(args_desc, ensure_ascii=False)
        tool_descs.append('%s: %s,args: %s,example:%s' % (t.name, t.description, args_desc, t.args_schema.Config.schema_extra["example"]))
    tool_descs = '\n'.join(tool_descs)
    return tools, tool_names, tool_descs

class Db1SearchInput(BaseModel):
    """用于查询知识库"""
    query: str = Field(description="需要查询的技术问题，用中文描述")
    knowledge_base_name: str = Field(default="dongdian", description="固定使用的知识库名称")
    top_k: int = Field(default=7, description="返回最相关的条目数量")
    score_threshold: float = Field(default=0.5, description="相似度分数阈值（0-1）")

    class Config:
        schema_extra = {
            "example": {
                "query": "主轴温度过热怎么解决？",
                "top_k": 5,
                "score_threshold": 0.6
            }
        }

@tool("db1_search",return_direct=False,args_schema=Db1SearchInput)
def db1_search(
        query: str = Field(description="查询历史经验"),
        knowledge_base_name: str = "dongdian",
        top_k: int = 7,
        score_threshold: float = 0.5
) -> str:
    """机床维修知识库检索工具，用于查询设备故障解决方案、技术参数等专业信息"""


@tool("weather_check", return_direct=False)
def weather_chcek(city: str = Field(description="城市名称")) -> str:
    """用于查询城市的天气"""
    try:
        return "今天成都的天气是25℃，多云小雨"
    except Exception as e:
        return "weather工具出现异常,执行失败"

class python_REPL_input(BaseModel):
    """只能用于执行python代码,如print("1+1"),不要用该工具进行搜索功能"""
    code: str = Field(description="为可执行的python代码")
    class Config:
        schema_extra = {
            "example": {
                "code": "print('1+2')"
            }
        }
@tool("python_REPL", return_direct=False, args_schema=python_REPL_input)
def python_REPL(code: str) -> str:
    try:
        python_repl = PythonREPL()
        ret = python_repl.run(code)
        return ret
    except Exception as e:
        return "pythonREPL工具出现异常,执行失败"

class yiwan_input(BaseModel):
    """一个用于查询机床、铣床传感器状态数据的工具，如果你要查询任何与机床、铣床有关的传感器数据，请使用该工具"""
    query: str = Field(description="应为一个与查询机床、铣床传感器状态数据有关的问题")
    class Config:
        schema_extra = {
            "example": {
                "query": "当前主轴温度是多少"
            }
        }
# def cosine_similarity(vec1: list, vec2: list) -> float:
#     """计算两个向量之间的余弦相似度"""
#     vec1 = np.array(vec1)
#     vec2 = np.array(vec2)
#     dot_product = np.dot(vec1, vec2)
#     norm1 = np.linalg.norm(vec1)
#     norm2 = np.linalg.norm(vec2)
#     return dot_product / (norm1 * norm2)
#
# def find_best_match(query_embedding: list, embeddings: list) -> int:
#     """计算 query 与每一行的余弦相似度，返回最匹配的行的索引"""
#     max_similarity = -1
#     best_index = None
#
#     for i, embedding in enumerate(embeddings):
#         similarity = cosine_similarity(query_embedding, embedding)
#         if similarity > max_similarity:
#             max_similarity = similarity
#             best_index = i
#
#     return best_index

# def get_embedding(texts: list) -> list:
#     """调用智谱清言 API 获取文本的 embedding"""
#     response = client.embeddings.create(
#         model="embedding-3",  # 使用 embedding-3 模型
#         input=texts
#     )
#     embeddings = [item['embedding'] for item in response['data']]
#     return embeddings

@tool("yiwan", return_direct=False, args_schema=yiwan_input)
def yiwan(query: str) -> str:
    try:
        file_name = 'D:\\笔记管理\大模型\\agent代码\\dongdian_v2\\agent\\tools\\sensor_table.txt'
        data = "当前系统中拥有的传感器及状态如下:\n"
        lines = []

        # 打开文件并逐行读取内容
        with open(file_name, 'r', encoding='utf-8') as file:
            i = 1
            for line in file:
                #打印每一行内容，使用strip()去除可能的前后空白字符
                # 去除前后空白字符
                cleaned_line = line.strip()
                data = data + f"{i}. {cleaned_line}\n"
                lines.append(cleaned_line)  # 将每一行添加到列表中
                i = i + 1

        # 分词函数
        def tokenize(text):
            return list(jieba.cut(text))
        # 创建TF-IDF向量器
        vectorizer = TfidfVectorizer(tokenizer=tokenize, lowercase=False)

        # 计算TF-IDF向量
        tfidf_matrix = vectorizer.fit_transform(lines + [query])

        # 获取查询的向量
        query_vec = tfidf_matrix[-1]

        # 计算余弦相似度
        similarities = cosine_similarity(query_vec, tfidf_matrix[:-1])

        # 找到最相似的行的索引
        best_match_index = np.argmax(similarities)

        # 输出最相关的内容
        if similarities[0, best_match_index] > 0:
            best_match_line = lines[best_match_index]
            data += f"\n根据查询 '{query}'，最相关的传感器涉及参数为:\n{best_match_line}"
        else:
            data += f"\n根据查询 '{query}'，未找到相关内容。"


        return data
    except Exception as e:
        return "yiwan工具出现异常,执行失败"
class tavily_Input(BaseModel):
    """一个用于查询任何与机床、铣床相关知识的知识库.不要使用该工具查询实时数据，如传感器数据"""
    query: str = Field(description="请输入查询内容，例如：'主轴温度过热怎么办？'")
    class Config:
        schema_extra = {
            "example": {
                "query": "主轴温度过热怎么办？"
            }
        }
@tool("tavily", return_direct=False, args_schema=tavily_Input)
def tavily(query: str) -> str:
    # try:
    #     tavily = TavilySearchResults(max_results=7)
    #     result = tavily.invoke(query)
    #     temp = ""
    #     i = 1
    #     for r in range(0,len(result)):
    #         if len(result[r]["content"]) < 400:
    #             temp = temp + f"{i}." + result[r]["content"]
    #             i = i + 1
    #     return temp
    # except Exception as e:
    #     return "tavily工具出现异常,执行失败"
    try:
        payload = {
            "query": query,
            "knowledge_base_name": "dongdian",
            "top_k": 3,
            "score_threshold": 1,
            "file_name": "",
            "metadata": {}
        }
        headers = {
            "accept": "application/json",
            "Content-Type": "application/json"
        }
        url = "http://127.0.0.1:7861/knowledge_base/search_docs"
        response = requests.post(url, json=payload, headers=headers, timeout=10)
        if response.status_code == 200:
            results = response.json()
            temp = ""
            i = 1
            for doc in results:
                content = doc.get("page_content", "")
                if len(content) < 400:
                    temp += f"{i}. {content}\n"
                    i += 1
            return temp if temp else "未找到相关知识库内容。"
        else:
            return f"知识库搜索请求失败，状态码: {response.status_code}"
    except Exception as e:
        return "知识库工具出现异常,执行失败"

class tavily_batch_Input(BaseModel):
    """是一个类似谷歌和百度的搜索引擎，搜索知识、天气、股票、电影、小说、百科等,如果这你不确定就应该搜索一下.你可以用该工具一次搜索多个问题"""
    queries: list[str] = Field(description="should be a list of search queries")
    class Config:
        schema_extra = {
            "example": {
                "queries": "['what is llm', 'what is ai']"
            }
        }
@tool("tavily_batch", return_direct=False, args_schema=tavily_batch_Input)
def tavily_batch(queries: list[str]) -> str:
    try:
        tavily = TavilySearchResults(max_results=7)
        result = tavily.batch(queries)
        temp = ""
        for r in range(len(result)):
            temp += "问题" + f"{r+1}:" + queries[r] + "\n"
            i = 1
            for w in range(len(result[r])):
                if len(result[r][w]["content"]) < 400:
                    temp += f"{i}." + result[r][w]["content"] + "\n"
                    i += 1
            temp += "\n"
        return temp

    except Exception as e:
        return "tavily_batch工具出现异常,执行失败"




def is_json(query):
# query1 = '{"query": "阿丽娜·萨巴伦卡 出生地"}' #是json,可直接json.loads
#query2 = "{'query':'阿丽娜·萨巴伦卡 出生地'}" #不是json是字符串,必须先dumps,再loadsdef is_json(query):
    # 检查是否为字符串类型
    if not isinstance(query, str):
        return -1

    # 检查是否是双引号包围的JSON字符串
    if query.startswith('{') and query.endswith('}') and query.count('"') > 1:
        return True

    # 检查是否是单引号包围的JSON字符串
    if query.startswith("{'") and query.endswith("'}"):
        return False

# import ast
# a = """{'query':'阿丽娜·萨巴伦卡 出生地'}"""
#print(tavily.invoke({"query":"成都 天气"}))
# a = json.dumps(a)
# print(tavily.invoke(ast.literal_eval(a)))












