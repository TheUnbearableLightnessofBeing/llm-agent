import os
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain.utilities import PythonREPL
os.environ['TAVILY_API_KEY'] = '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'  # travily搜索引擎api key

