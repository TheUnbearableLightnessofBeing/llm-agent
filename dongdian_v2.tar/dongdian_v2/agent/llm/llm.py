from langchain.agents import AgentExecutor, create_structured_chat_agent
from langchain import hub
from tools.tool import get_tools
from langchain_openai import ChatOpenAI
import os
os.environ["OPENAI_API_KEY"] = 'None'

def get_ChatOpenAI(base_url: str,
                   model: str = None,
                   temperature: float = 0.5,
                   verbose: bool = True,
                   streaming: bool = True,
                   max_tokens: int = 4096):
    return ChatOpenAI(base_url=base_url,
                      model=model,
                      temperature=temperature,
                      verbose=verbose,
                      streaming=streaming,
                      max_tokens=max_tokens)


def agent_chat(query: str):
    llm = get_ChatOpenAI(base_url="http://127.0.0.1:9997/v1",
                         model="qwen2_7b",
                         temperature=0.5,
                         verbose=True,
                         streaming=True,
                         max_tokens=32768)
    tools = get_tools()
    prompt = hub.pull("hwchase17/structured-chat-agent")
    agent = create_structured_chat_agent(llm, tools, prompt)
    agent_executor = AgentExecutor(
        agent=agent, tools=tools, verbose=True, handle_parsing_errors=True
    )
    return agent_executor.invoke({f"input": f"{query}"})



