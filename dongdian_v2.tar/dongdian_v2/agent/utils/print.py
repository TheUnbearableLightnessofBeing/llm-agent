from datetime import datetime


def print_green(str: str):
    print(f"\033[32m{str}\033[0m")

def print_blue(str: str):
    print(f"\033[34m{str}\033[0m")


def print_red(str: str):
    print(f"\033[31m{str}\033[0m")

def current_time():
    current_time = datetime.now()

    # 格式化时间，只显示年、月、日、小时、分钟和秒
    formatted_time = current_time.strftime('%Y-%m-%d %H:%M:%S')
    return formatted_time