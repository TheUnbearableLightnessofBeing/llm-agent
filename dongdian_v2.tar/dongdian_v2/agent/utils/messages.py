from langchain_core.messages import HumanMessage, AIMessage, ToolMessage
from langgraph.graph.message import AnyMessage
from typing_extensions import TypedDict
from typing import Union, List


def return_message(messages: Union[List[AnyMessage], AnyMessage]):
    if isinstance(messages, List):
        temp = {"messages": []}
        for message in messages:
            if isinstance(message, AIMessage):
                print(f"\033[32mAI:{message.content}\033[0m\n")
            if isinstance(message, HumanMessage):
                print(f"\033[32mUser:{message.content}\033[0m\n")
            temp["messages"].append(message)
        return temp
    if isinstance(messages, AnyMessage):
        if isinstance(messages, AIMessage) or isinstance(messages, ToolMessage):
            print(f"\033[32mAI:{messages.content}\033[0m\n")
        if isinstance(messages, HumanMessage):
            print(f"\033[32mUser:{messages.content}\033[0m\n")
        return {"messages": messages}
    raise TypeError("\033[31mmessages must be List[AnyMessage] or AnyMessage\033[0m")


def history_trans(state: TypedDict):
    chat = ""
    for mes in state["messages"]:
        if isinstance(mes, AIMessage) or isinstance(mes, ToolMessage):
            chat = chat + "AI:" + mes.content + "\n"
        if isinstance(mes, HumanMessage):
            chat = chat + "User:" + mes.content + "\n"
    return chat