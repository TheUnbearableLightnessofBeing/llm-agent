import json
from typing import List
import ast
class thought_node:
    def __init__(self, task, thought_id, thought, reason=None, tool=None, tool_input=None, response=None, critic=None ,score=None,depth=None):
        self.task = task
        self.thought_id = thought_id
        self.thought = thought
        self.reason = reason
        self.tool = tool
        self.tool_input = tool_input
        self.response = response
        self.critic = critic
        self.score = score
        self.pre = []
        self.next = []
        self.depth = depth

def thought_parse(json_string):
    thought_info = json.loads(json_string)
    response = thought_info["response"]
    critic = thought_info["critic"]
    score = int(thought_info["score"])
    return response, critic, score


def print_node(nodes: list[thought_node]):
    if  isinstance(nodes, List):
        ...
    else:
        nodes = [nodes]
    for n in nodes:
        print(n.thought_id)
        print(n.thought)
        print(n.reason)
        print(n.tool)
        print(n.tool_input)
        print(n.response)
        print(n.critic)
        print(n.score)
        print(n.pre)
        print(n.next)
        print("depth:" + str(n.depth))
        print("--------")

def solver_parse(json_string):
    thought_info = json.loads(json_string)
    return thought_info["response"]


