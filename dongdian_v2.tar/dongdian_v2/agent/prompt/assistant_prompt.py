ASSISTANT_PROMPT = """System:你是一个聊天助手,请竭尽所能回答用户问题.
历史对话记录:
{chat_history}

问题:{input}

"""