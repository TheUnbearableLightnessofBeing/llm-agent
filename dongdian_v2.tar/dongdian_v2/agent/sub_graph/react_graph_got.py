from typing import Annotated
from typing_extensions import TypedDict
from langgraph.graph.message import AnyMessage, add_messages
from langchain_core.runnables import Runnable, RunnableConfig
from langchain.prompts import (
    ChatPromptTemplate
)
from agent.utils.messages import (return_message,
                            history_trans)
from agent.utils.print import (print_green, print_blue, print_red)
import os
from langchain_core.messages import HumanMessage,AIMessage
from agent.prompt.react_prompt_chinese import REACT_TEMPLATE_CHINESE
from datetime import datetime
from agent.tools.tool import get_tools
from langchain_openai import ChatOpenAI
from langgraph.graph import END, StateGraph, START
from langgraph.checkpoint import MemorySaver
os.environ["OPENAI_API_KEY"] = 'None'
import ast

class State(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]

tools, tool_names, tool_descs = get_tools()

# 工具调用确保temperature=1
# llm = ChatOpenAI(base_url="http://127.0.0.1:9997/v1",model="qwen2_7b-zFZtlOnQ", temperature=0)
llm = ChatOpenAI(base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",model="qwen-max",
                 temperature=1,
                 api_key="sk-039f7d796d214a67ba5061f3380c995d")
template = REACT_TEMPLATE_CHINESE
chat_prompt = ChatPromptTemplate.from_messages([template]).partial(tool_names=tool_names, tool_description=tool_descs)
runnable = chat_prompt | llm


class Assistant:
    def __init__(self, runnable: Runnable):
        self.runnable = runnable

    def __call__(self, state: State, config: RunnableConfig):

        #configuration = config.get("configurable", {})
        #passenger_id = configuration.get("passenger_id", None)
        #state = {**state, "user_info": passenger_id}
        result = self.runnable.invoke({"time": datetime.now(), "chat_history": history_trans(state),
                                           "input": state["messages"][0].content})
        #print_blue(state["messages"][0].content)
        message = result.content
        action_i = message.rfind('\nAction:')
        action_input_i = message.rfind('\nAction Input:')
        if action_i != -1 and action_input_i != -1:
            mark = message.find('}', action_input_i)
            result.content = message[:mark + 1]

        return return_message(result)

def query_human(state: State):
    if "我执行了Action,但是Action被终止了" in state["messages"][-2].content:
        temp = state["messages"].pop()
        return {"messages": temp}

    user_input = input("\033[34m请输入,若输入n则结束对话:\033[0m")
    state["user_input"] = user_input
    return return_message(HumanMessage(content=f"{user_input}"))

def should_continue_1(state: State):
    messages = state['messages']
    last_message = messages[-1].content
    # If the LLM makes a tool call, then we route to the "tools" node
    if last_message == "n":
        return "__end__"
    # Otherwise, we stop (reply to the user)
    #print(last_message)
    return "assistant"

def should_continue_2(state: State):
    messages = state['messages']
    last_message = messages[-1].content

    if "Final Answer" in last_message:
        return "conclude"
    if "Action Input:" in last_message and "Action:" in last_message:
        return "excute_tools"

    return "assistant"


def excute_tools(state: State):
    message = state["messages"][-1].content
    action_i = message.rfind('\nAction:')
    action_input_i = message.rfind('\nAction Input:')
    action = message[action_i + len('\nAction:'):action_input_i].strip()
    mark = message.find('}', action_input_i)
    action_input = message[action_input_i + len('\nAction Input:'):mark+1].strip()
    global tools
    prefix = f"Observation:我执行了{action}工具,得到的结果是:\n"
    try:
        for t in tools:
            #print(f"----{action}-----{t.name}-----")
            if t.name == action:
                action_input = ast.literal_eval(action_input)
                result = t.invoke(action_input)
                #print(t.invoke(action_input))
                print_red(action_input)
                if result == "":
                    return return_message(AIMessage(content=prefix + "没有得到任何结果"))
                return return_message(AIMessage(content=prefix + result))

        return return_message(AIMessage(content=prefix + "没有匹配到工具,我应该确保自己生成了正确的工具名称"))
    except Exception as e:
        return return_message(AIMessage(content=prefix + f"{action}执行出错,{e}"))
    
def conclude(state: State):
    template_conclude = """历史对话记录:{chat_history}
    
    请你根据上面的历史对话记录进行总结,回答原始问题.
    给出对回答的批评.
    给出你对该回答的评分.评分规则如下:
        1.如果回答错误,没有解决问题,分数不超过5分.
        2.如果回答基本正确解决了问题得6分.
        3.在2.的基础上,如果回答具体详细,但仍有情况未考虑到,给7分.
        4.在3.的基础上,如果回答尽可能考虑到了全部情况,并且针对利用现有手段无法解决的部分提出了原因和建议,给8-10分.
    你的批评需要着重考虑回答该问题是否需要实时性数据支撑,例如问题如果是询问设备故障的原因,
    回答给出了一系列可能的故障组件,你需要考察回答中是否使用传感器等实时监控装置检查了该组件当前的工作状态是好是坏.
    而不是让回答中给出不确定的故障原因.如果回答中没有使用组件的实时传感器数据,你应该指出.
    use following json foramt:
    {json}

    Begin! Remember to use chinese to respond.
    原始问题:{input}
    """
    # final_answer = state["messages"][-1].content.split("Answer:")[1]
    c = f"""{{
            "response": "总结历史对话记录,不要添加你自己附加的内容如评价、反思和改进等.输出内容不要换行",
            "critic": "给出你认为的response的错误或不足,如果你认为没有就不要给出,要回答得详细具体.输出内容不要换行",
            "score": "根据上述的评分规则给出分数."
    }}"""
    chat_prompt = ChatPromptTemplate.from_messages([template_conclude])
    runnable = chat_prompt | llm
    result = runnable.invoke({"chat_history":history_trans(state),
                              "input":state["messages"][0].content,"json":c})
    return {"messages": result}

#############
builder = StateGraph(State)
builder.add_node("assistant", Assistant(runnable))
builder.add_node("excute_tools", excute_tools)
builder.add_node("conclude",conclude)

builder.add_edge(START, "assistant")
# builder.add_conditional_edges(
#     "query_human",
#     should_continue_1,
# )
builder.add_conditional_edges(
    "assistant",
    should_continue_2
)
builder.add_edge("excute_tools", "assistant")
builder.add_edge("conclude",END)

memory = MemorySaver()

######
react_graph = builder.compile()

react_graph_config = {"recursion_limit": 10}
#config = {"configurable": {"thread_id": 42}}
##################
#print_blue(str(datetime.now()) + " AI系统正在启动中...")
#query = "生成打印字符串'ss'20次的python代码,然后执行该代码,输出代码的原始执行结果"
#query = "User:你好,python是什么"
#query = "你好,特朗普最近遭遇了什么大事"
#print_green("User" + query)
# final_state = app.invoke(
#     {"messages": [HumanMessage(content="你好"), return_message(AIMessage(content="你好,我是Qwen,需要我帮你做什么"))["messages"]]},
#     config=config
# )
#
#
#
# """interrupt_after
# 如果None继续,会保留excute_tools的结果添加到消息中,然后返回到assistant
# 如果输入非None继续，会导致excute_tools返回的消息被删除,并且添加我们输入的拒绝的理由到消息中,然后返回到assistant"""
#
# """interrupt_before,
# None继续,会执行excute_tools结点,然后返回到assistant
# 非None,不会执行excute_tools,而是将我们输入的拒绝理由添加到消息中,然后返回到assistant"""
#
# # 获得当前state
# snapshot = app.get_state(config)
# # .next不为空表示程序还没有进入end,还要继续进入下一个节点
# # 注意,每次需要检查snapshot.next时,是当interrupt出现,app.invoke可以直接完成整个流程
# while snapshot.next:
#         user_input = input(
#             "\033[34m你同意本次Action吗? 输入'y'继续;否则,给出你想要接下来做的事.\n\033[0m"
#         )
#         if user_input.strip() == "y":
#             # Just continue
#             final_state = app.invoke(
#                 None,
#                 config,
#             )
#         else:
#             final_state = app.invoke(
#                 {
#                     "messages": return_message([AIMessage(content=f"我执行了Action,但是Action被终止了"),
#                                  HumanMessage(content=f"{user_input}")])["messages"]},
#                 config,
#             )
#         snapshot = app.get_state(config)
#
# #print(final_state["messages"])













