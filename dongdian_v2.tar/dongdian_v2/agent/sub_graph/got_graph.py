from datetime import datetime

from langchain.prompts import (
    ChatPromptTemplate
)
from openai import OpenAI

from agent.utils.print import (print_green, print_blue, print_red)
import os
from langchain_core.messages import HumanMessage,AIMessage
from agent.prompt.got_prompt import *
from agent.prompt.generate_prompt import *
from agent.prompt.solver_prompt import *
from langchain_openai import ChatOpenAI
from langgraph.graph import END, StateGraph, START
os.environ["OPENAI_API_KEY"] = 'None'
from typing import  List, TypedDict
from agent.sub_graph.react_graph_got import react_graph, react_graph_config
import threading






tools_prefix= {"tavily": "使用tavily查询:", "yiwan":"使用yiwan查询"}
# tools_prefix= {"knowledge_base": "使用knowledge查询:", "yiwan":"使用yiwan查询"}
def add_thought_node(left, right):
    if not isinstance(left, list):
        left = [left]
    if not isinstance(right, list):
        right = [right]
    return left + right


class GOT(TypedDict):
    task: str
    new_nodes: List
    graph_state: List[thought_node]
    mark_id: int
    
llm = ChatOpenAI(base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",model="qwen-long",
                 temperature=1,
                 api_key="sk-039f7d796d214a67ba5061f3380c995d")
# llm_aggregate = ChatOpenAI(base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",model="qwen2-72b-instruct",
#                  temperature=1,
#                  api_key="sk-31940590568944b696115b071d709c85")
# llm = ChatOpenAI(
#     base_url="http://117.139.126.36:8000/v1",  # 注意端口需与服务端一致
#     model="/home/llm/models/qwen/Qwen2.5-72B-Instruct",           # 模型名称严格匹配API返回
#     api_key="EMPTY",                          # 本地部署无需密钥
#     temperature=1,                          # 可选参数
#     max_tokens=500                            # 可选参数
# )

thoughts_generate_prompt = THOUGHTS_GENERATE_PROMPT
thoughts_generate_chat_prompt = ChatPromptTemplate.from_messages([thoughts_generate_prompt]).partial(generate_json=generate_json)
thoughts_generate = thoughts_generate_chat_prompt | llm
# regex_pattern = r"Thought:\s*(.+)\s*(#E\d+)\s*=\s*(\w+)\s*\[([^\]]+)\]"
# regex_pattern2 = r"Thought:\s*(.+)\s*(#E\d+)\s*"

def get_thought(state: GOT):
    task = state["task"]
    task_node = thought_node(task=task, thought_id=0, thought=task, score=5, depth=0)
    state["graph_state"].append(task_node)
    mark_id = len(state["graph_state"]) - 1
    # task_node = thought_node(task=task,thought_id=mark_id,thought=task,score=5)
    # state["tasks"].append(task_node)
    # if len(state["graph_state"]) != 0:
    #     state["graph_state"][-1].next.append(mark_id)
    #     task_node.pre.append(state["graph_state"][-1].thought_id)

    result = thoughts_generate.invoke({"task": task,"time":datetime.now()})
    result = ast.literal_eval(result.content)
    # for r in result:
    #     print_blue(r)
    new_nodes = []

    for r in result:
        l = len(state["graph_state"])
        n = thought_node(depth=state["graph_state"][mark_id].depth+1,task=task,thought_id=l,thought=r["thought"],reason=r["reason"],tool=r["tool"],tool_input=r["tool_input"])
        n.pre.append(mark_id)
        state["graph_state"].append(n)
        state["graph_state"][mark_id].next.append(l)
        new_nodes.append(n)

    return {"new_nodes": new_nodes, "graph_state": state["graph_state"], "mark_id": mark_id}

# 不一定有state参数就一定是结点,也可以是在某个结点内会传入state给该函数
def _get_current_task(state: GOT):
    # 通过results长度标记该执行哪个task
    # 一个task对应一个results里面一个元素
    # results长度为<steps长度,说明任务没有执行完
    if len(state["new_nodes"]) == 0:#执行完了
        return 0
    else:#开始执行下一个
        return 1


def tool_excute(state,node):
    #node = state["new_nodes"][mark]
    tool, tool_input = node.tool, node.tool_input

    if tool == "tavily" or tool == "yiwan":
        react_query = tools_prefix[tool] + tool_input
        print_blue(react_query)
        result = react_graph.invoke(
            {"messages": [HumanMessage(content=react_query)]},
            config=react_graph_config
        )

    # if tool == "LLM":
    #     input = node.thought + tool_input
    #     print_blue(input)
    #     result = react_graph.invoke(
    #         {"messages": [HumanMessage(content=input)]},
    #         config=react_graph_config
    #     )

    result = result["messages"][-1].content.strip()
    # temp = state["graph_state"]
    # temp_node = temp[state["mark_id"]+_step]
    #print_green(result)
    node.response, node.critic, node.score = thought_parse(result)
    state["new_nodes"].remove(node)
    return

def tool_execution(state: GOT):
    threads = []
    for mark in range(len(state["new_nodes"])):
        thread = threading.Thread(target=tool_excute, args=(state,state["new_nodes"][mark]))
        threads.append(thread)

    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    return {"graph_state":state["graph_state"], "new_nodes": state["new_nodes"]}




def solver(state: GOT):
    task = state["task"]
    thoughts = f"User:{task}\n"
    nodes = [x for x in state["graph_state"][1:]]
    for n in nodes:
        thoughts += f"AI:{n.tool_input}\nAI:{n.response}\n"

    prompt = SOLVER_PROMPT.format(chat_history=thoughts,json_solver=json_solver,input=task)

    #print_blue(prompt)
    result = llm.invoke(prompt).content.strip()
    #print_blue(result)
    response = solver_parse(result)
    state["graph_state"][0].response = response
    return {"graph_state": state["graph_state"]}



def _route_1(state: GOT):
    _step = _get_current_task(state)
    #state["graph_state"][1].score = 5
    if _step == 0:
        return "solver"
    return "tool"


# def _route_3(state: GOT):
#     print_node(state["graph_state"])
#     input()
#     if state["task"] == "end":
#         return END
#     else:
#         return "thought"


graph = StateGraph(GOT)
graph.add_node("thought", get_thought)
graph.add_node("tool", tool_execution)
graph.add_node("solver", solver)

graph.add_edge(START, "thought")
graph.add_edge("thought", "tool")
graph.add_conditional_edges("tool", _route_1)
graph.add_edge("solver", END)



reason_without_obs_graph = graph.compile()
# for s in reason_without_obs_graph.stream({"task": "机床主轴温度过高"}):
#     #print(s)
#     print("---")


# #task2 = "将2,54,1,6,57,12,4,5,10,233按从小到大排序"
# task2 = "机床主轴温度过高"
# task2 = "9.11和9.8哪个更大"

def plan_and_excute(task:str):
    #task_node = thought_node(task=task, thought_id=0, thought=task, score=5, depth=0)
    result = reason_without_obs_graph.invoke({"task": task,"graph_state":[]})
    return result["graph_state"][0]









