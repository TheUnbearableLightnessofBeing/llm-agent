# from react_graph import react_graph,config
# from langchain_core.messages import HumanMessage,AIMessage
# from agent.utils.messages import return_message
#
# final_state = react_graph.invoke(
#     {"messages": [HumanMessage(content="你好"), return_message(AIMessage(content="你好,我是Qwen,需要我帮你做什么"))["messages"],
#                   return_message(HumanMessage(content="今天成都天气如何"))["messages"]]},
#     config=config
# )
# #print(final_state["messages"][-1])