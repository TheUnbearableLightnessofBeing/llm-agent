from langchain.embeddings import HuggingFaceEmbeddings
def get_embedding_model():
    try:
        model_name = 'D:/model/bce-embedding-base_v1'
        model_kwargs = {'device': 'cuda'}
        encode_kwargs = {'normalize_embeddings': True}

        embed_model = HuggingFaceEmbeddings(
            model_name=model_name,
            model_kwargs=model_kwargs,
            encode_kwargs=encode_kwargs
          )
        return embed_model

    except Exception as e:
        return -1