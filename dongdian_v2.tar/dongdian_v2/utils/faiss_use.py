from langchain_community.vectorstores import FAISS
from embedding_model import get_embedding_model


# 从数据库取出query加载vecstore.  vectorstore:存query,metadata=[{'id':}]
# def load_faiss_db1(db):
#     try:
#         query = db.get_all_query_id()
#         vecstore = FAISS(embedding_function=get_embedding_model())
#         for temp in query:
#             vecstore.add_texts(texts=[temp[0]], metadatas=[dict(id=temp[1])])
#         return vecstore
#
#     except Exception as e:
#         return -1


# 不需要save了，每次add都会保存到数据库
# def faiss_save(db, path : str):
#     db.save_local(path)

# 从大模型得到五元组，然后添加进向量库和数据库，该部分日后实现
def faiss_add_text(vecstore, text: str):
    # 向量库添加query和id
    vecstore.add_texts(texts=[], metadatas=None, ids=[])
    # 数据库添加id,query,answer,time,score
    return

# 取出，相似度计算,直接用自带的similarity


# #a = FAISS('D:/model/bce-embedding-base_v1')
# texts = ["FAISS is an important library"]
# db1 = FAISS.from_texts(texts, get_embedding_model())
# db1.docstore._dict
