import pymysql
import colorama
import logging.config
from log.log_config import LOGGING_CONFIG

logging.config.dictConfig(LOGGING_CONFIG)
class Mysql:
    """
    TODO: 应先创建数据库
    +--------+------+------+-----+---------+-------+
    | Field  | Type | Null | Key | Default | Extra |
    +--------+------+------+-----+---------+-------+
    | index  | int  | NO   | PRI | NULL    |       |
    | text   | text | YES  |     | NULL    |       |
    | tensor | blob | YES  |     | NULL    |       |
    +--------+------+------+-----+---------+-------+
    :param user: 用户名
    :param pw: 密码
    :param db_name: 数据库名称
    :param tb_name: 表名称
    :param host: 地址(缺省值‘localhost’)
    :param port: 端口(缺省值3306)
    """

    def __init__(self, user, pw, db_name, tb_name, host='localhost', port=3306):
        self._user = user
        self._pw = pw
        self._db_name = db_name
        self._tb_name = tb_name
        self._host = host
        self._port = port
        self._db = -1



    def connect(self):
        try:
            self._db = pymysql.connect(host=self._host, user=self._user, passwd=self._pw, port=self._port)
            if self._db != -1:
                logging.info("✅ database connected")
            return 1

        except Exception as e:
            logging.error("❌ database connected error")
            return -1

    def add_row(self, id, query, answer, time, score):
        """
        添加向量集到数据库
        :param index: 序号
        :param text: 文本
        :param tensor: 向量
        """
        # 连接MySQL数据库
        try:
            cursor = self._db.cursor()
            # 将向量存入数据库
            cursor.execute('USE ' + self.__db_name)
            cursor.execute(
                'INSERT INTO ' + self.__tb_name + ' (id,query,answer,time,score) VALUES (%s,%s,%s,%s,%s)',
                (id, query, answer, time, score))
            try:
                self._db.commit()  # 提交事务
                # print('insertion completed')

            except Exception as e:
                logging.error("❌ add_row Commit Error", e)
                self._db.rollback()
                cursor.close()
                return -1

            return 1
        except Exception as e:
            logging.error("❌ add_row Error", e)
            return -1

    def get_by_id(self, id):
        try:
            cursor = self._db.cursor()
            cursor.execute('USE ' + self._db_name)
            cursor.execute('SELECT answer,time,score FROM ' + self._tb_name + ' WHERE id = %s',
                           id)
            # tensors = [np.frombuffer(row[0], dtype=np.float32) for row in cursor.fetchall()]
            # tensors = np.array(tensors)
            result = cursor.fetchall()[0]
            cursor.close()
            return result

        except Exception as e:
            logging.error("❌ get_by_id Error", e)
            return -1

    def get_all_query_id(self):
        try:
            cursor = self._db.cursor()
            cursor.execute('USE ' + self._db_name)
            cursor.execute('SELECT query,id FROM ' + self._tb_name)
            # tensors = [np.frombuffer(row[0], dtype=np.float32) for row in cursor.fetchall()]
            # tensors = np.array(tensors)
            result = cursor.fetchall()
            cursor.close()
            return result

        except Exception as e:
            logging.error("❌ get_all_query Error", e)
            return -1


    def close_db(self):
        try:
            self._db.close()
            return 1
        except Exception as e:
            return -1












