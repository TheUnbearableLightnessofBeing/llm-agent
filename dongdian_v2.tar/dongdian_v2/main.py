from typing import Annotated,List
from typing_extensions import TypedDict
from langgraph.graph.message import AnyMessage, add_messages

from agent.utils.messages import (return_message,
                            history_trans)
from agent.utils.print import (print_green, print_blue, print_red)
import os
import json
from langchain_core.messages import HumanMessage,AIMessage
from agent.prompt.react_prompt_chinese import REACT_TEMPLATE_CHINESE
from datetime import datetime
from agent.tools.tool import get_tools, is_json
from langchain_openai import ChatOpenAI
from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.graph import END, StateGraph, START
from langgraph.checkpoint import MemorySaver
os.environ["OPENAI_API_KEY"] = 'None'
import ast
from agent.prompt.reflexion_prompt import *
from agent.prompt.assistant_prompt import *
from agent.sub_graph.got_graph import plan_and_excute



CONTROLLER = """System:你是一名任务分配专家,你的任务是根据用户输入的问题将其分配给不同的工具进行处理.

你能使用的工具如下:
(1) plan[input]: 该工具可对复杂问题分解为若干子步骤,然后一一求解子步骤得到原始问题的答案.当用户询问机床、铣床相关问题,你务必使用该工具.
(2) LLM[input]: A pretrained LLM like yourself. Useful when you need to act with general
world knowledge and common sense. Prioritize it when you are confident in solving the problem
yourself. Input can be any instruction.

use following json format to respond:
{json_controller}

question:{input}

"""
json_controller = f"""{{
            "tool": "你选择的工具,should be plan or LLM.",
            "reason": "你选择该工具的理由.",
            "tool_input": "给该工具的输入.请务必详细."
    }}"""
llm = ChatOpenAI(base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
                 model="qwen-max",
                 temperature=1,
                 api_key="sk-039f7d796d214a67ba5061f3380c995d")
class State(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]
    tool:str
    tool_input:str
    user_input:str
    tasks:List[str]
    process:List[str]

def controller(state: State):
    print(history_trans(state))
    state["user_input"] = input("\033[34m请输入,若输入end则开启新的对话:\033[0m")
    if state["user_input"] == "end":
        return {**return_message(HumanMessage(content="end")),"tool":"LLM"}

    prompt = CONTROLLER.format(json_controller=json_controller,input=state["user_input"])
    result = llm.invoke(prompt).content
    #print(result)
    result = ast.literal_eval(result)
    if result["tool"] == "plan":
        state["tasks"].append(state["user_input"])
        return {"user_input": state["user_input"],
                "tool": result["tool"], "tool_input": result["tool_input"],
                "tasks": state["tasks"]}
    return {**return_message(HumanMessage(content=state["user_input"])),"user_input":state["user_input"],"tool":result["tool"],"tool_input":result["tool_input"],
            "tasks":state["tasks"]}


def route(state:State):
    if state["tool"] == "plan":
        return "plan"
    if state["messages"][-1].content == "end":
        return END
    else:
        return "assistant"

def route_2(state:State):

    if state["tasks"][-1] == "end":
        return END
    else:
        time = len(state["tasks"])
        # time_ = (time-1)%2
        #
        # if time_ == 0:
        human_input = input(f"\033[34m已经执行了{time-1}轮任务,输入end结束,否则继续:\033[0m")
        if human_input == "end":
            return END
        else:
            return "plan"
        # return "plan"



def plan(state:State):
    a = state["tasks"][-1]
    result = plan_and_excute(a).response
    return return_message([HumanMessage(content=a),AIMessage(content=result)])

def assistant(state:State):
    prompt = ASSISTANT_PROMPT.format(input=state["user_input"],chat_history=history_trans(state))
    ret = llm.invoke(prompt).content

    return return_message(AIMessage(content=ret))



def reflexion(state:State):

    human_input = input("\033[34m如果你想提供一些反馈,请输入,否则输入n:\033[0m")
    if human_input != "n":
        state["messages"].append(HumanMessage(content=human_input))
    prompt = REFLEXION_PROMPT.format(json_reflexion=json_reflexion,chat_history=history_trans(state),input=state["tasks"][0])
    a = llm.invoke(prompt).content
    a = ast.literal_eval(a)
    next_task = a["next_task"]
    print_green("AI:\n")
    print_green("1.response:" + a["response"])
    print_green("2.critic:" + a["critic"])
    print_green("3.next_task:" + next_task)
    state["tasks"].append(next_task)
    state["messages"].pop()
    if human_input != "n":
        state["messages"].pop()
    return {"messages":AIMessage(content=a["response"]),"tasks":state["tasks"]}



builder = StateGraph(State)
builder.add_node("controller", controller)
builder.add_node("plan", plan)
builder.add_node("assistant",assistant)
builder.add_node("reflexion",reflexion)

builder.add_edge(START, "controller")
builder.add_conditional_edges("controller",route)
builder.add_edge("assistant","controller")
builder.add_edge("plan", "reflexion")
builder.add_conditional_edges("reflexion",route_2)

app = builder.compile()

while True:
    print_blue("我是东电机器人,专为您服务的机床、铣床故障诊断助手.\n我的主要任务是帮助您解决在操作机床过程中遇到的各种技术难题,\n包括但不限于故障诊断、维护建议和性能优化等.\n"
               "如果您有关于机床的任何问题,请随时向我咨询.")
    result = app.invoke({"tasks":[]})
    if len(result["tasks"]) !=0:
        print("\033[34m\n你对本次回答的打分:\n1.如果解决了你的问题请给出6-10分\n2.否则给出0-5分\033[0m")
        human_point = input("\033[34m你的打分:\033[0m")
        # 结合process存入数据库













