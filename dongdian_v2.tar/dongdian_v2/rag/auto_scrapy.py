# 自动在web爬取文档
# 调用paddleocr处理
# 调用add_text


