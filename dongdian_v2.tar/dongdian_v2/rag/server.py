# "/vectorstore/faiss_kb1"
from langchain_community.vectorstores import FAISS
from utils.embedding_model import get_embedding_model
import os
from fastapi import FastAPI
import asyncio
from utils.database import Mysql
from add_text import *


kb1 = None
db1 = None
app = FastAPI(title='faiss服务', description='faiss服务')
db = Mysql(user="agent", pw="qweqwe123", db_name="agent", tb_name="")

@app.get(path='/rag/load_kb1')
async def load_kb1(faiss_path="/db/faiss_kb1"):
    global kb1
    kb1 = None
    try:
        if not os.path.isfile(faiss_path):
            temp = FAISS(embedding_function=get_embedding_model())
            temp.save_local(faiss_path)
        else:
            temp = FAISS.load_local(faiss_path, get_embedding_model())
        kb1 = temp
        return {"message": "Load success", "code": "200"}
    except Exception as e:
        return {"message": "Load failed", "code": "404"}



@app.post(path='/rag/kb1_search/')
async def get_kb1(item: dict):
    global kb1
    if kb1 is None:
        return {"message": "Not load", "code": "404"}
    try:
        query = dict["query"]
        k = dict["k"]
        return {"message": kb1.similarity_search_with_score(query=query, k = k), "code": "200"}
    except Exception as e:
        return {"message": "Post body error", "code": "404"}




@app.get(path='/rag/kb1_add_text/{text_path}')
async def kb1_add_text(text_path: str):
    if kb1 is None:
        return {"message": "Not load", "code": "404"}
    try:
        documents = load_documents(text_path)
        chunks = split_documents(documents)
        add_to_faiss(chunks=chunks, vectorstore=kb1, faiss_path="/db/faiss_kb1")

    except Exception as e:
        return {"message": "add_text failed", "code": "404"}
    else:
        result = await load_kb1()
        if result["code"] == 200:
            return {"message": "Reload success", "code": "200"}
        else:
            return {"message": "Reload failed", "code": "404"}


# db1 加载db1
@app.get(path='/rag/load_db1')
async def load_db1(db=db):
    try:
        query = db.get_all_query_id()
        vecstore = FAISS(embedding_function=get_embedding_model())
        for temp in query:
            vecstore.add_texts(texts=[temp[0]], metadatas=[dict(id=temp[1])])
        global db1
        db1 = vecstore
        return {"message": "Load success"}
    except Exception as e:
        return {"message": "Load failed"}


# 搜索db1，需要查数据库
@app.post(path='/rag/db1_search/')
async def get_db1(item: dict, db=db):
    global db1
    if kb1 is None:
        return {"message": "Not load", "code": "404"}
    try:
        query = dict["query"]
        k = dict["k"]
        temp = kb1.similarity_search_with_score(query=query, k=k)

        # 还未完全实现，还需要去数据库根据ID查询


        return {"message": kb1.similarity_search_with_score(query=query, k=k), "code": "200"}
    except Exception as e:
        return {"message": "Post body error", "code": "404"}








asyncio.run(load_kb1())
asyncio.run(load_db1())


# @app.get(path='/add_text')
# def add_text(text_path: str):
#     global vectorstore
#     if vectorstore is None:
#         raise HTTPException(status_code=403, detail="add text failed")
#     documents = load_documents(text_path)
#     chunks = split_documents(documents)
#     add_to_faiss(chunks, vectorstore)
#     return {"message": "success"}










