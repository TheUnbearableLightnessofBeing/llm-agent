# 加了async的函数既不能单独执行，也不能不在一个函数里面直接await
# 使用async定义一个异步函数
import asyncio

# 使用async定义一个异步函数
async def fetch_data():
    print("开始获取数据...")
    await asyncio.sleep(2)  # 模拟异步操作，例如网络请求
    print("数据获取完成")
    return {'data': 1}

# 定义另一个异步函数，用于执行其他操作
async def other_task():
    print("开始执行其他任务...")
    await asyncio.sleep(1)  # 模拟耗时操作
    print("其他任务完成")
    return {'other_data': 2}

# 使用asyncio.run来运行异步主函数
async def main():
    # 创建fetch_data任务
    task1 = asyncio.create_task(fetch_data())
    # 创建other_task任务
    task2 = asyncio.create_task(other_task())

    # 等待两个任务完成
    result1 = await task1
    result2 = await task2

    print("任务1结果:", result1)
    print("任务2结果:", result2)

# 运行main函数
asyncio.run(main())