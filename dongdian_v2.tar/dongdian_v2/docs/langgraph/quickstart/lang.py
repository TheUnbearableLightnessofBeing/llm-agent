from tools.tool import get_tools
from agent.llm.llm import get_ChatOpenAI
from langgraph.prebuilt import create_react_agent
from langgraph.checkpoint import MemorySaver


tools = get_tools()
model = get_ChatOpenAI(base_url="http://127.0.0.1:9997/v1",
                       model="qwen2_7b",
                       temperature=0.5,
                       verbose=True,
                       streaming=True,
                       max_tokens=32768)
system_message = "You are a helpful assistant. Respond only in Spanish."
memory = MemorySaver()
app = create_react_agent(
    model, tools, messages_modifier=system_message, checkpointer=memory
)
app.step_timeout = 5
query = "成都天气如何"


#messages = app.invoke({"messages": [("human", query)]})
for step in app.stream({"messages": [("human", query)]},
                       {"recursion_limit": 7},
                       stream_mode="updates"):
    print(step)

# {
#         "input": query,
#         "output": messages["messages"][-1].content,
# }
