from langchain_core.output_parsers.openai_functions import JsonOutputFunctionsParser
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI
members = ["Researcher", "Coder"]
system_prompt = (
    "You are a supervisor tasked with managing a conversation between the"
    " following workers:  {members}. Given the following user request,"
    " respond with the worker to act next. Each worker will perform a"
    " task and respond with their results and status. When finished,"
    " respond with FINISH."
)
# Our team supervisor is an LLM node. It just picks the next agent to process
# and decides when the work is completed
options = ["FINISH"] + members
# Using openai function calling can make output parsing easier for us
function_def = {
    "name": "route",
    "description": "Select the next role.",
    "parameters": {
        "title": "routeSchema",
        "type": "object",
        "properties": {
            "next": {
                "title": "Next",
                "anyOf": [
                    {"enum": options},
                ],
            }
        },
        "required": ["next"],
    },
}
prompt = ChatPromptTemplate.from_messages(
    [
        "system", system_prompt,
        "{messages}",
            "system",
            "Given the conversation above, who should act next?"
            " Or should we FINISH? Select one of: {options}"
    ]
).partial(options=str(options), members=", ".join(members))

llm = ChatOpenAI(base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",model="qwen-max",
                 temperature=0,
                 api_key="sk-039f7d796d214a67ba5061f3380c995d")

# llm = ChatOpenAI(base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",model="qwen2-7b-instruct",
#                  temperature=1,
#                  api_key="")
# llm = ChatOpenAI(base_url="https://api.deepseek.com",model="deepseek-chat",
#                  temperature=1,
#                  api_key="sk-2e4051a1dc8c420ca77999257071d816")
supervisor_chain = (
        prompt
        | llm.bind_functions(functions=[function_def], function_call="route")

)
from langchain_core.messages import BaseMessage, HumanMessage,ToolMessage,FunctionMessage
d = supervisor_chain.invoke(input={"messages":HumanMessage(content="你好,不要调用函数")})
print(type(d))
#print(llm.invoke([d,FunctionMessage(id=d.id,content="你记得上条消息吗"),HumanMessage(content="你记得上条消息吗")]))
# for member in members:
#     # We want our workers to ALWAYS "report back" to the supervisor when done
#     workflow.add_edge(member, "supervisor")
# # The supervisor populates the "next" field in the graph state
# # which routes to a node or finishes
# conditional_map = {k: k for k in members}
# conditional_map["FINISH"] = END
# workflow.add_conditional_edges("supervisor", lambda x: x["next"], conditional_map)
# # Finally, add entrypoint
# workflow.add_edge(START, "supervisor")

