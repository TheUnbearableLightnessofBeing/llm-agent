from langchain_core.messages import AIMessage, BaseMessage, HumanMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI
from agent.prompt.basic_reflection_prompt import *
from typing import List, Sequence
from typing import Annotated
from typing_extensions import TypedDict
from langgraph.graph.message import AnyMessage, add_messages
from langgraph.graph import END, StateGraph, START
from agent.utils.messages import (return_message,
                            history_trans)


prompt_1 = ChatPromptTemplate.from_messages([BASIC_REFLECTION_PROMPT_1])
prompt_2 = ChatPromptTemplate.from_messages([BASIC_REFLECTION_PROMPT_2])

# llm = ChatOpenAI(base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",model="qwen-max",
#                  temperature=0,
#                  api_key="sk-31940590568944b696115b071d709c85")
llm = ChatOpenAI(base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",model="qwen-max",
                 temperature=0,
                 api_key="sk-039f7d796d214a67ba5061f3380c995d")

llm_1 = prompt_1 | llm
llm_2 = prompt_2 | llm

class State(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]


def generation_node(state: State):
    result = llm_1.invoke({"input": state["messages"]})
    return return_message(result)

def reflection_node(state: State):
    # Other messages we need to adjust
    cls_map = {"ai": HumanMessage, "human": AIMessage}
    # First message is the original user request. We hold it the same for all nodes
    translated = [state["messages"][0]] + [
        cls_map[msg.type](content=msg.content) for msg in state["messages"]
    ]
    res = llm_2.invoke({"input": translated})
    # We treat the output of this as human feedback for the generator
    return return_message(HumanMessage(content=res.content))


builder = StateGraph(State)
builder.add_node("generate", generation_node)
builder.add_node("reflect", reflection_node)
builder.add_edge(START, "generate")


def should_continue(state: List[BaseMessage]):
    if len(state["messages"]) > 2:
        # End after 1 iterations
        return END
    return "reflect"


builder.add_conditional_edges("generate", should_continue)
builder.add_edge("reflect", "generate")
graph = builder.compile()

print(graph.invoke({"messages": HumanMessage(
            content="Generate an essay on the topicality of The Little Prince and its message in modern life"
        )}))

"""多轮反思过程中， 双方都要获取彼此的完整对话记录才行"""
"""若不考虑token数量，无需专门在提示中开设一个{反思}{他人意见}"""