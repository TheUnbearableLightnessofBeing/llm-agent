from llm import get_ChatOpenAI
from langchain import LLMChain
from prompt.react_template import (ReactPromptTemplate,
                                         ReactOutputParser,
                                         template)
from tools.tool import get_tools
from langchain.agents import AgentExecutor, LLMSingleActionAgent
import os
os.environ["OPENAI_API_KEY"] = 'None'




prompt = ReactPromptTemplate(
    template=template,
    tools=get_tools(),
    # This omits the `agent_scratchpad`, `tools`, and `tool_names` variables because those are generated dynamically
    # This includes the `intermediate_steps` variable because that is needed
    input_variables=["input", "intermediate_steps"]
)

output_parser = ReactOutputParser()
llm = get_ChatOpenAI(base_url="http://127.0.0.1:9997/v1",
                     model="qwen2_7b",
                     temperature=0.5,
                     verbose=True,
                     streaming=True,
                     max_tokens=32768)

llm_chain = LLMChain(llm=llm, prompt=prompt)
tools = get_tools()
tool_names = [tool.name for tool in tools]
agent = LLMSingleActionAgent(
    llm_chain=llm_chain,
    output_parser=output_parser,
    stop=["\nObservation:"],
    allowed_tools=tool_names
)
agent_executor = AgentExecutor.from_agent_and_tools(agent=agent, tools=tools, verbose=True)
agent_executor.run("今天成都的天气怎么样")